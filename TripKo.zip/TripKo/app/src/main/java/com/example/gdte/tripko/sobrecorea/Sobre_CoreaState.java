package com.example.gdte.tripko.sobrecorea;

public class Sobre_CoreaState extends Sobre_CoreaViewModel {

    // put the model state here
}
