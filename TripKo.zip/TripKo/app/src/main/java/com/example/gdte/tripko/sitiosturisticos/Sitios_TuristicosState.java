package com.example.gdte.tripko.sitiosturisticos;

public class Sitios_TuristicosState extends Sitios_TuristicosViewModel {

    // put the model state here
}
