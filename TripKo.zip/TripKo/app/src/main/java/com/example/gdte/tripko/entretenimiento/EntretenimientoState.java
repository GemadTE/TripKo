package com.example.gdte.tripko.entretenimiento;

public class EntretenimientoState extends EntretenimientoViewModel {

    // put the model state here
}
