package com.example.gdte.tripko.gastronomiaregiones;

import com.example.gdte.tripko.data.RegionesItem;
import com.example.gdte.tripko.data.RepositoryContract;

import java.lang.ref.WeakReference;
import java.util.List;

public class Gastronomia_RegionesPresenter implements Gastronomia_RegionesContract.Presenter {

    public static String TAG = Gastronomia_RegionesPresenter.class.getSimpleName();

    private WeakReference<Gastronomia_RegionesContract.View> view;
    private Gastronomia_RegionesState state;
    private Gastronomia_RegionesContract.Model model;
    private Gastronomia_RegionesContract.Router router;

    public Gastronomia_RegionesPresenter(Gastronomia_RegionesState state) {
        this.state = state;
    }

    @Override
    public void fetchRegionListData() {
        // Log.e(TAG, "onStart()");

        //call the model
        model.fetchRegionListData(new RepositoryContract.GetRegionListCallback() {

            @Override
            public void setRegionList(List<RegionesItem> regiones) {
                state.regiones = regiones;

                view.get().displayRegionListData(state);
            }
        });

    }

    @Override
    public void goHomeButtonClicked() {
        router.navigateToHomeScreen();
    }

    @Override
    public void selectRegionListData(RegionesItem item) {
        router.passDataToGastronomiaListScreen(item);
        router.navigateToGastronomiaListScreen();
    }

    @Override
    public void injectView(WeakReference<Gastronomia_RegionesContract.View> view) {
        this.view = view;
    }

    @Override
    public void injectModel(Gastronomia_RegionesContract.Model model) {
        this.model = model;
    }

    @Override
    public void injectRouter(Gastronomia_RegionesContract.Router router) {
        this.router = router;
    }
}
