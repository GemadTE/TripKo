package com.example.gdte.tripko.ciudadesprincipales;

public class Ciudades_PrincipalesViewModel {

    // put the view state here
    public String data;
}
