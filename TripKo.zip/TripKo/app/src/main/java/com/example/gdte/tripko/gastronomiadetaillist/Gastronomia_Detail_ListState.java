package com.example.gdte.tripko.gastronomiadetaillist;

public class Gastronomia_Detail_ListState extends Gastronomia_Detail_ListViewModel {

    // put the model state here
}
