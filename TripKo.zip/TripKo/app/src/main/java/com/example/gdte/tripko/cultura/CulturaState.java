package com.example.gdte.tripko.cultura;

public class CulturaState extends CulturaViewModel {

    // put the model state here
}
