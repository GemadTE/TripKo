package com.example.gdte.tripko.preguntasfrecuentes;

public class Preguntas_FrecuentesState extends Preguntas_FrecuentesViewModel {

    // put the model state here
}
