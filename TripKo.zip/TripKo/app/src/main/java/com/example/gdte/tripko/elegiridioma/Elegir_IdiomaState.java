package com.example.gdte.tripko.elegiridioma;

public class Elegir_IdiomaState extends Elegir_IdiomaViewModel {

    // put the model state here
}
