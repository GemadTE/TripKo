package com.example.gdte.tripko.elegiridioma;

public class Elegir_IdiomaViewModel {

}
