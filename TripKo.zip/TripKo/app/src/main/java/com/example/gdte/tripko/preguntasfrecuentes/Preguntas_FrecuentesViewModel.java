package com.example.gdte.tripko.preguntasfrecuentes;

public class Preguntas_FrecuentesViewModel {

    // put the view state here
    public String data;
}
