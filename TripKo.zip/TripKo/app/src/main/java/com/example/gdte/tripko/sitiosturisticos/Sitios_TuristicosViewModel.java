package com.example.gdte.tripko.sitiosturisticos;

public class Sitios_TuristicosViewModel {

    // put the view state here
    public String data;
}
