package com.example.gdte.tripko.ciudadesprincipales;

public class Ciudades_PrincipalesState extends Ciudades_PrincipalesViewModel {

    // put the model state here
}
