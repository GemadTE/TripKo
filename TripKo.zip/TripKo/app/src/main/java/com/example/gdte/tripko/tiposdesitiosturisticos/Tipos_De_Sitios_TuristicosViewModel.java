package com.example.gdte.tripko.tiposdesitiosturisticos;

public class Tipos_De_Sitios_TuristicosViewModel {

    // put the view state here
    public String data;
}
