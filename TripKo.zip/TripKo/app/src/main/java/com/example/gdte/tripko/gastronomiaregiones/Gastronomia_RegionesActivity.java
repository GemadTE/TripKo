package com.example.gdte.tripko.gastronomiaregiones;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.example.gdte.tripko.R;
import com.example.gdte.tripko.data.RegionesItem;

public class Gastronomia_RegionesActivity
        extends AppCompatActivity implements Gastronomia_RegionesContract.View {

    public static String TAG = Gastronomia_RegionesActivity.class.getSimpleName();

    private Gastronomia_RegionesContract.Presenter presenter;

    private ImageButton preguntasFrecuentesImageButton,homeImageButton;

    private Gastronomia_RegionesAdapter gastronomia_regionesAdapter;

    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gastronomia_regiones);

        preguntasFrecuentesImageButton = findViewById(R.id.preguntasFrecuentesImageButton);
        homeImageButton = findViewById(R.id.homeImageButton);

        recyclerView = findViewById(R.id.region_list);

        gastronomia_regionesAdapter = new Gastronomia_RegionesAdapter(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegionesItem regionesItem = (RegionesItem) v.getTag();
                presenter.selectRegionListData(regionesItem);
            }
        });

        recyclerView.setAdapter(gastronomia_regionesAdapter);

        homeImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                presenter.goHomeButtonClicked();
            }
        });


        // do the setup
        Gastronomia_RegionesScreen.configure(this);

        //do some work
        presenter.fetchRegionListData();

    }



    @Override
    public void displayRegionListData(final Gastronomia_RegionesViewModel viewModel) {

        runOnUiThread(new Runnable() {

            @Override
            public void run() {

                //deal with the data
                gastronomia_regionesAdapter.setItems(viewModel.regiones);
            }
        });
    }

    @Override
    public void injectPresenter(Gastronomia_RegionesContract.Presenter presenter) {
        this.presenter = presenter;
    }
}
