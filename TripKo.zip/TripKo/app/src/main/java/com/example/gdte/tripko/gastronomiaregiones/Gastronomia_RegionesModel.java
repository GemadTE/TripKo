package com.example.gdte.tripko.gastronomiaregiones;

import com.example.gdte.tripko.data.RepositoryContract;

public class Gastronomia_RegionesModel implements Gastronomia_RegionesContract.Model {

    public static String TAG = Gastronomia_RegionesModel.class.getSimpleName();

 private RepositoryContract repository;

    public Gastronomia_RegionesModel(RepositoryContract repository) {
        this.repository = repository;
    }

    @Override
    public void fetchRegionListData(
            final RepositoryContract.GetRegionListCallback callback){

        repository.loadRegiones(new RepositoryContract.FetchRegionesDataCallback() {

            @Override
            public void onRegionesDataFetched(boolean error) {
                if(!error){
                    repository.getRegionList(callback);
                }
            }
        });
    }
}
