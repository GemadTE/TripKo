package com.example.gdte.tripko.splash;

public class SplashState extends SplashViewModel {

    // put the model state here
}
