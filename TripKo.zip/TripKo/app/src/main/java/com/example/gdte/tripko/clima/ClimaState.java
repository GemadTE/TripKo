package com.example.gdte.tripko.clima;

public class ClimaState extends ClimaViewModel {

    // put the model state here
}
