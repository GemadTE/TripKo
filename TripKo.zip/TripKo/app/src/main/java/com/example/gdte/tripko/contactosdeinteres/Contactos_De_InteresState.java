package com.example.gdte.tripko.contactosdeinteres;

public class Contactos_De_InteresState extends Contactos_De_InteresViewModel {

    // put the model state here
}
