package com.example.gdte.tripko.gastronomialist;

public class GastronomiaListState extends GastronomiaListViewModel {

    // put the model state here
}
