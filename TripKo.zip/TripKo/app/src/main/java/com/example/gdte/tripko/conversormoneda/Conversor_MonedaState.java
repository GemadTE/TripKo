package com.example.gdte.tripko.conversormoneda;

public class Conversor_MonedaState extends Conversor_MonedaViewModel {

    // put the model state here
}
