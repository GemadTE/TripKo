package com.example.gdte.tripko.tiposdesitiosturisticos;

public class Tipos_De_Sitios_TuristicosState extends Tipos_De_Sitios_TuristicosViewModel {

    // put the model state here
}
