package com.example.gdte.tripko.splash;

public class SplashViewModel {

    // put the view state here
    public String data;
}
