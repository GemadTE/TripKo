package com.example.gdte.tripko.menuprincipal;

public class Menu_PrincipalState extends Menu_PrincipalViewModel {

    // put the model state here
}
