package com.example.gdte.tripko.gastronomiaregiones;

public class Gastronomia_RegionesState extends Gastronomia_RegionesViewModel {

    // put the model state here
}
