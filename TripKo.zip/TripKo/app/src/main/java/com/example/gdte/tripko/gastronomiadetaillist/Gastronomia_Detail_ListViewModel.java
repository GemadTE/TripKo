package com.example.gdte.tripko.gastronomiadetaillist;

public class Gastronomia_Detail_ListViewModel {

    // put the view state here
    public String data;
}
