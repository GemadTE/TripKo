package com.example.gdte.tripko.transportecategory;

public class Transporte_CategoryState extends Transporte_CategoryViewModel {

    // put the model state here
}
