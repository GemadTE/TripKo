package com.example.gdte.tripko.clima;

public class ClimaViewModel {

    // put the view state here
    public String data;
}
