package com.example.gdte.tripko.gastronomiaregiones;

import com.example.gdte.tripko.data.RegionesItem;

import java.util.List;

public class Gastronomia_RegionesViewModel {

    // put the view state here
    public List<RegionesItem> regiones;
}
