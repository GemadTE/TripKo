package com.example.gdte.tripko.contactosdeinteres;

public class Contactos_De_InteresViewModel {

    // put the view state here
    public String data;
}
