package com.example.gdte.tripko.sobrecorea;

public class Sobre_CoreaViewModel {

    // put the view state here
    public String data;
}
