package com.example.gdte.tripko.conversormoneda;

public class Conversor_MonedaViewModel {

    // put the view state here
    public String data;
}
