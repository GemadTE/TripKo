package com.example.gdte.tripko.gastronomiaregiones;

import com.example.gdte.tripko.data.RegionesItem;
import com.example.gdte.tripko.data.RepositoryContract;

import java.lang.ref.WeakReference;

public interface Gastronomia_RegionesContract {

    interface View {

        void displayRegionListData(final Gastronomia_RegionesViewModel viewModel);

        void injectPresenter(Presenter presenter);

    }

    interface Presenter {

        void selectRegionListData(RegionesItem item);

        void fetchRegionListData();

        void goHomeButtonClicked();

        void injectView(WeakReference<View> view);

        void injectModel(Model model);

        void injectRouter(Router router);

    }

    interface Model {

        void fetchRegionListData(
                RepositoryContract.GetRegionListCallback callback);
    }

    interface Router {
        void navigateToGastronomiaListScreen();

        void navigateToHomeScreen();

        void passDataToGastronomiaListScreen(RegionesItem item);

        void passStateToNextScreen(Gastronomia_RegionesState state);

        Gastronomia_RegionesState getStateFromNextScreen();

    }
}
