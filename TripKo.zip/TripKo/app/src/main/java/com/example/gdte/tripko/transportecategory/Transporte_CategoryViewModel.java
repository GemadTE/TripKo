package com.example.gdte.tripko.transportecategory;

public class Transporte_CategoryViewModel {

    // put the view state here
    public String data;
}
