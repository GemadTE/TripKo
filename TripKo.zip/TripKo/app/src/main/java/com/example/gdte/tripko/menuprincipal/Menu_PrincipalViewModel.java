package com.example.gdte.tripko.menuprincipal;

public class Menu_PrincipalViewModel {

    // put the view state here
    public String data;
}
