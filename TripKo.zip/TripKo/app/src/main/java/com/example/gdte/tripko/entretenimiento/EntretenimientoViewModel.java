package com.example.gdte.tripko.entretenimiento;

public class EntretenimientoViewModel {

    // put the view state here
    public String data;
}
