package com.example.gdte.tripko.cultura;

public class CulturaViewModel {

    // put the view state here
    public String data;
}
